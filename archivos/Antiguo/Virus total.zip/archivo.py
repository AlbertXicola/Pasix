import hashlib
import os
import requests
import pymongo
import time
import shutil

carpeta_Para_analizar = "Para_Analizar"

# Ruta del directorio de destino
ruta_destino_Limpio = "Finalizado/Limpio"
ruta_destino_Cuarentena = "Finalizado/Cuarentena"
ruta_destino_Malicioso = "Finalizado/Malicioso"

# Conexión a MongoDB
client = pymongo.MongoClient("mongodb://localhost:27017/")

# Verificar si la base de datos "Proyecto" existe
if "Proyecto" in client.list_database_names():
    print("La base de datos 'Proyecto' ya existe.")
    db = client["Proyecto"]
else:
    print("La base de datos 'Proyecto' no existe. Creando la base de datos...")
    db = client["Proyecto"]

# Verificar si la colección "Archivos" existe
if "Archivos" in db.list_collection_names():
    print("La colección 'Archivos' ya existe.")
    collection = db["Archivos"]
else:
    print("La colección 'Archivos' no existe. Creando la colección...")
    collection = db["Archivos"]

# Clave de API de VirusTotal
api_key = "2f047d42c57a702fd720dd049e5d7f8d24baf8811faf42d34226e703be6270a9"

# URL base de la API de VirusTotal v3
base_url = "https://www.virustotal.com/api/v3"
print("-" * 50)
# Función para calcular el hash SHA-256 de un archivo
def calcular_sha256_hash(file_path):
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as file:
        while True:
            data = file.read(65536)  # Lee el archivo en bloques de 64 KB
            if not data:
                break
            sha256_hash.update(data)
    return sha256_hash.hexdigest()

# Función para enviar un archivo a VirusTotal v3
def enviar_a_virustotal(file_path):
    url = f"{base_url}/files"
    headers = {
        "x-apikey": api_key,
    }
    files = {"file": (file_path, open(file_path, "rb"))}
    response = requests.post(url, files=files, headers=headers)
    return response

# Función para obtener resultados de VirusTotal v3 utilizando la URL "self"
def obtener_resultados_virustotal(file_url):
    headers = {
        "x-apikey": api_key,
    }
    response = requests.get(file_url, headers=headers)
    return response

# Lista todos los archivos en la carpeta
archivos = os.listdir(carpeta_Para_analizar)

# Recorre los archivos y calcula el hash SHA-256

for i, archivo in enumerate(archivos):
    archivo_path = os.path.join(carpeta_Para_analizar, archivo)
    if os.path.isfile(archivo_path):
        sha256_hash = calcular_sha256_hash(archivo_path)
        print(f"Archivo: {archivo}")
        print(f"SHA-256 Hash: {sha256_hash}")

        # Buscar el hash en la base de datos
        resultado = collection.find_one({"Nuestro Hash": sha256_hash})
        if resultado:
            print("Datos encontrados en nuestra base de datos")
            print(resultado)
        else:
            print("El hash no existe en la base de datos.")

            # Enviar el archivo a VirusTotal v3
            response = enviar_a_virustotal(archivo_path)

            if response.status_code == 200:
                vt_response = response.json()
                print("Resultado de VirusTotal (Primera Solicitud):")
                print(vt_response)

                # Extraer la URL "self" de la respuesta
                file_url = vt_response["data"]["links"]["self"]

                # Obtener resultados de VirusTotal utilizando la URL "self"
                response2 = obtener_resultados_virustotal(file_url)
                if response2.status_code == 200:
                    vt_response2 = response2.json()
                    print("Resultado de VirusTotal (Segunda Solicitud):")
                    print(vt_response2)
                    
                    # Verificar si la clave 'last_analysis_stats' existe en la respuesta
                    last_analysis_stats = vt_response2.get("data", {}).get("attributes", {}).get("stats", {}).get("malicious", 0)


                    # Obtener el valor de 'malicious' si existe, o establecerlo en 0 si no
                    malicious_segunda_solicitud = last_analysis_stats

                    # Agregar los datos a la base de datos
                    data_to_insert = {
                        "Nombre Archivo": archivo,
                        "Nuestro Hash": sha256_hash,
                        "id_API": vt_response["data"]["id"],
                        "Maldades Detectadas": malicious_segunda_solicitud,
                    }
                    collection.insert_one(data_to_insert)
                    if malicious_segunda_solicitud == 0:
                        destino = ruta_destino_Limpio
                    elif malicious_segunda_solicitud <= 5:
                        destino = ruta_destino_Cuarentena
                    elif malicious_segunda_solicitud > 5:
                        destino = ruta_destino_Malicioso

                    shutil.move(archivo_path, os.path.join(destino, archivo))
                    print("Datos agregados a la base de datos.")
                    
                else:
                    print("Error al obtener resultados de VirusTotal con el self.")
            else:
                print("Error al enviar el archivo a VirusTotal.")

        print("-" * 50)

        # Si se han procesado 4 archivos, espera 1 minuto
        if (i + 1) % 4 == 0:
            print("Esperando Temporizador")
            time.sleep(60)  # Espera 60 segundos (1 minuto)

# Cierra la conexión de MongoDB cuando hayas terminado
client.close()
