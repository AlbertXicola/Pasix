// UserMenu.js
import React from 'react';
import './css/01-usermenu.css';

const UserMenu = ({ handleMenuClick }) => {
  return (
    <div className="user-menu-container">
      <userbutton onClick={() => handleMenuClick('Perfil')}>Perfil</userbutton>
      <userbutton onClick={() => handleMenuClick('Configuración')}>Configuración</userbutton>
      <userbutton onClick={() => handleMenuClick('Cerrar Sesión')}>Cerrar Sesión</userbutton>
    </div>
  );
};

export default UserMenu;