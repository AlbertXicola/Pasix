import React, { useState } from 'react';
import './css/01-register.css';

const Register = ({ handleMenuClick }) => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showMainMenuButton, setShowMainMenuButton] = useState(true);

  const handleRegister = () => {
    // Aquí puedes implementar la lógica de registro
    console.log(`Usuario: ${username}, Correo: ${email}, Contraseña: ${password}`);
  };

  const handleMainMenuClick = () => {
    // Volver al menú principal
    handleMenuClick('Inicio');
  };

  return (
    <div className="register-container">
        
      {showMainMenuButton && (
        <button className="close-button" type="button" onClick={handleMainMenuClick}>
          boton oculto
        </button>
      )}
      <h2 className="register-h2">Registro</h2>
      <form className="register-form">
        <label className="register-label">
          
          <input placeholder='Nombre'
            className="register-input"
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </label>
        <label className="register-label">
        
          <input placeholder='Email'
            className="register-input"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </label>
        <label className="register-label">
         
          <input placeholder='Password'
            className="register-input"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>
        <button className="register-button" type="button" onClick={handleRegister}>
          Registrarse
        </button>
      </form>
    </div>
  );
};

export default Register;
